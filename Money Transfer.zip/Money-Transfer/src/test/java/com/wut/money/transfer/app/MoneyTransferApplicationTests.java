package com.wut.money.transfer.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyTransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
